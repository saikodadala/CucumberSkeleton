package Base;

import org.openqa.selenium.WebDriver;

/**
 * Created by Karthik on 10/21/2016.
 */
public class BaseUtil {

    public WebDriver Driver;

}
