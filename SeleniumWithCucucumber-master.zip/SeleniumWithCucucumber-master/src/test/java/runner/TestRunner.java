package runner;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;
import cucumber.api.testng.AbstractTestNGCucumberTests;
import net.serenitybdd.cucumber.CucumberWithSerenity;
import org.junit.runner.RunWith;

import java.io.File;


@RunWith(Cucumber.class)
//@RunWith (.CucumberWithSerenityclass)
@CucumberOptions(features = {"src/test/java/features/Login.feature"} , format = {"pretty","json:target/cucumber.json","html:target/site/cucumber-pretty"},
        glue = "steps",plugin = { "com.cucumber.listener.ExtentCucumberFormatter:target/cucumber-reports/report.html","pretty:target/cucumber-pretty.txt","html:target/cucumber-html-report",
        "json:target/cucumber.json", "pretty:target/cucumber-pretty.txt",
        "usage:target/cucumber-usage.json", "junit:target/cucumber-results.xml" })

public class TestRunner extends AbstractTestNGCucumberTests{
}
