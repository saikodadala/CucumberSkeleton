package steps;

import cucumber.api.java.After;
import cucumber.api.java.Before;

/**
 * Created by g.dimartino on 09/04/17.
 * GlobalHooks class contains the methods to be executed before/after each scenario
 */
public class GlobalHooks {

	/**
	 * start method will be executed before each test of the feature files
	 */
	@Before
	public static void start () {
		System.out.println("\nBefore each test\n");
	}

	/**
	 * startWithTag method will be executed before each test annotated with '@Tag' of the feature files
	 */
	@Before ("@Tag")
	public static void startWithTag () {
		System.out.println("\nBefore each @Tag test\n");
	}

	/**
	 * close method will be executed after each test of the feature files
	 */
	@After
	public static void close () {
		System.out.println("\nAfter each test\n");
	}

	/**
	 * closeWithTag method will be executed after each test annotated with '@Tag' of the feature files
	 */
	@After ("@Tag")
	public static void closeWithTag () {
		System.out.println("\nAfter each @Tag test\n");
	}

}