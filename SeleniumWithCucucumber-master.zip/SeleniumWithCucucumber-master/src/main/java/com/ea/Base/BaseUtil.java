package com.ea.Base;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

/**
 * Created by Karthik on 10/21/2016.
 */
public class BaseUtil{

    public WebDriver Driver;

    public BaseUtil() {
        Driver = new ChromeDriver();

    }

}
