import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import jxl.Workbook;
import jxl.Sheet;

public class ExcelUtility {	
	static int totalNoOfRows,totalNoOfCols;
	static FileInputStream fs;
	static Workbook wb;
	static Sheet sh ;
	private static void open(String fileName,String sheetName) throws IOException
	{
		String workingDir = System.getProperty("user.dir");	
		System.out.println(workingDir);		
		try
		{
		String FilePath = workingDir+"\\TestData\\"+fileName+".xls";
		fs = new FileInputStream(FilePath);
		wb = Workbook.getWorkbook(fs);

		// TO get the access to the sheet
		sh = wb.getSheet(sheetName);

		// To get the number of rows present in sheet
		totalNoOfRows = sh.getRows();

		// To get the number of columns present in sheet
		totalNoOfCols = sh.getColumns(); 	
			
		}
		catch(Exception e)
		{
			wb.close();
			fs.close();
			e.printStackTrace();	
		}
		
	}
	public static String GetCellvalue(String expression) throws IOException
	{
		       //Formate Filepath>SheetName>ColumnName
		       String CellGetContent=null;
			   String s1=expression;  
			  String[] words=s1.split(">");//splits the string based on >
			  open(words[0],words[1]);
			  CellGetContent = sh.getCell(getColumnValue(words[2]),1).getContents();
				
				//System.out.println(CellGetContent);
				wb.close();
				fs.close();	
	     return CellGetContent;
	}
	public static List<String> GetCellvalue(String fileName,String workbook,String flag) throws IOException
	{
		       List<String> dataList = new ArrayList<String>();	
		       
			   open(fileName,workbook);
			   int row=getRowValue(flag);
			   for (int i=1;i<totalNoOfCols;i++)
			   {
				   if(!sh.getCell(i,row).getContents().isEmpty())
				   {
				   dataList.add(sh.getCell(i,row).getContents().toString());
				   }
				   else
				   {
					   break;
				   }
			   }
				
				//System.out.println(CellGetContent);
				wb.close();
				fs.close();	
	     return dataList;
	}
	 private static int getColumnValue(String columnname)
	 {
		List<String> headerList = new ArrayList<String>();
		int columnvalue=0; 
	 	//Storing the Headers into the list  
	  for(int i=0;i<totalNoOfCols;i++)
	  {
	  	headerList.add(sh.getCell(i,0).getContents());	  	
	  }    
	   for(int i=0;i<headerList.size();i++)
	  {
	  	if(headerList.get(i).equals(columnname))
	  	{
	  		columnvalue=i;  		
	  		break;
	  	}
	  }
	  return columnvalue;
	 }
     private static int getRowValue(String flag)
     {
    	 List<String> RowHeaderList = new ArrayList<String>();
    	 int rowvalue=0;  
    	   
    	  for(int i=0;i<totalNoOfRows;i++)
    	  {
    		  if(!sh.getCell(0, i).getContents().isEmpty())
    		  {
    	  	  RowHeaderList.add(sh.getCell(0, i).getContents().toString());
    		  }
    		  else
    		  {
    			  break;
    		  }
    	  	//log.info sheet1.getCell(0, i).getContents()
    	  }
    	   for(int i=0;i<RowHeaderList.size();i++)
    	  {
    	  	if(RowHeaderList.get(i).equals(flag))
    	  	{
    	  		rowvalue=i;  		
    	  		break;
    	  	}    	  
    	 }
    	 return rowvalue;
     }

}